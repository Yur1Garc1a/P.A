Public class ExercicioMedia {
   Public static void main (String[] args){
	   int soma1,soma2,soma3,media;
	   		soma1 = 8+9+7;
	   		soma1=soma1/3;
		   soma2= 4+5+6;
		   soma2= soma2/3;
		   soma3=soma1+soma2;
		   media= soma3/2;
		 System.out.println("A m�dia entre 8,9,7 � de " +soma1+ " E a m�dia entre 4,5,6 � " +soma2+ ", a soma das duas m�dia � de " +soma3+ " e a m�dia entre esses n�meros � " +media);
}
}