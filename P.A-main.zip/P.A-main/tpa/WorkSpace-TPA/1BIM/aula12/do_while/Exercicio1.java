package dowhile;

public class Exercicio1 {
    public static void main(String[] args) {
        int numero = 0;
        do {
            System.out.println(numero);
            numero += 2;
        } while (numero <= 500);
    }
}