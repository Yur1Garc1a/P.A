
public class Exercicio1 {

	public static void main(String[] args) {
		double b = 145;
		double a = 134;
		double c =0;
		while (a <= b) {
			a += 2.5;
			b += 2;
			c++;
		}
		System.out.println("a quantidade de anos �: "+c+ " anos");
	}

}
