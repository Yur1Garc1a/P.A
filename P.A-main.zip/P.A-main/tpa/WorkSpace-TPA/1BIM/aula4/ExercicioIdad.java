
public class ExercicioIdad {
	public static void main (String[] args) {
		int anoNasc, anoAtual, idade;
		anoNasc=2007;
		anoAtual=2023;
		idade=  anoAtual - anoNasc;
		System.out.println("Sua idade � "+idade);
		
	}
	

}
