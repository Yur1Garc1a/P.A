
public class ExercicioIdade {
	public static void main(Strings [] args) {
		int idade;
		int ano;
		int nascimento;
		ano=2023;
		nascimento=2007;
		idade=ano+nascimento;
		System.out.println("A idade � " +idade);
				
	}

}
