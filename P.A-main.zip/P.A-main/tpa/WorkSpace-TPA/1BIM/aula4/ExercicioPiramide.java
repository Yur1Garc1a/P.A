public class ExercicioPiramide {
	public static void main(String[]args) {
		int base;
		int altura;
		int area;
		base=50;
		altura=49;	
		area = (base*altura)/2;
		System.out.println("o valor da area do triangulo � " + area);
		
	}
	

}
