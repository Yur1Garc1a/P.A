import java.util.Scanner;
public class Exercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		int i=0;
		while(i<=500) {
			System.out.println(i);
			i= i+2;
		}
		
		in.close();
	}

}
