import java.util.Scanner;
public class Exercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		int i=1;
		while(i<=100) {
			System.out.println(i);
			i++;
		}
		
		in.close();
	}

}
